#include "platform_memory.h"

MemoryPool* _AHB0;
MemoryPool* _AHB1;
