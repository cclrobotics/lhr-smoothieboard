<?xml version="1.0"?>
<?xml-stylesheet type="text/css" href="http://www.shapeoko.com/wiki/skins/common/feed.css?303"?>
<feed xmlns="http://www.w3.org/2005/Atom" xml:lang="en">
		<id>http://www.shapeoko.com/wiki/index.php?title=Special:RecentChanges&amp;feed=atom</id>
		<title>ShapeOko  - Recent changes [en]</title>
		<link rel="self" type="application/atom+xml" href="http://www.shapeoko.com/wiki/index.php?title=Special:RecentChanges&amp;feed=atom"/>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php/Special:RecentChanges"/>
		<updated>2014-10-29T19:11:37Z</updated>
		<subtitle>Track the most recent changes to the wiki in this feed.</subtitle>
		<generator>MediaWiki 1.18.0</generator>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=3D_Printing&amp;diff=7526&amp;oldid=7518</id>
		<title>3D Printing</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=3D_Printing&amp;diff=7526&amp;oldid=7518"/>
				<updated>2014-10-29T19:00:03Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;Filament: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 19:00, 29 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan='4' align='center' class='diff-multi'&gt;(One intermediate revision by one user not shown)&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 546:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 546:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Another potential source of material is plastic welding rod: http://www.usplastic.com/catalog/item.aspx?itemid=22851&amp;amp;catid=881&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Another potential source of material is plastic welding rod: http://www.usplastic.com/catalog/item.aspx?itemid=22851&amp;amp;catid=881&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;−&lt;/td&gt;&lt;td style=&quot;background: #ffa; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;http://reprap.org/wiki/Printing_materials&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;* http://www.reddit.com/r/3Dprinting/wiki/filamentchart&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;* &lt;/ins&gt;http://reprap.org/wiki/Printing_materials&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;====Filament Specifications====&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;====Filament Specifications====&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 844:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 845:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://openfabpdx.com/2013/09/05/fff-printing-guidelines/&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://openfabpdx.com/2013/09/05/fff-printing-guidelines/&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://www.amazon.com/gp/aw/d/1497537460&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://www.amazon.com/gp/aw/d/1497537460&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;* http://neyasystems.com/tailoring-mechanical-designs-for-3d-printing/&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;===Material Comparisons===&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;===Material Comparisons===&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Upgrade_Overview&amp;diff=7524&amp;oldid=7519</id>
		<title>Upgrade Overview</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Upgrade_Overview&amp;diff=7524&amp;oldid=7519"/>
				<updated>2014-10-27T23:38:15Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;Sources: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 23:38, 27 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan='4' align='center' class='diff-multi'&gt;(One intermediate revision by one user not shown)&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 139:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 139:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;===NEMA 23 motors===&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;===NEMA 23 motors===&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;Upgrading the motors is usually done to:&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;* move the machine faster&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;* move a large, heavy spindle&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;there's no intrinsic reason to upgrade from NEMA17 motors.&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Documented for the ShapeOko 2 in this forum post: [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=2344&amp;amp;p=17845 Re: Caleb's Shapeoko 2 #3164]. [http://www.shapeoko.com/forum/viewtopic.php?f=10&amp;amp;t=2348 NEMA 23 Z-axis for shapeoko 2]. Note that these may need longer fasteners --- 15mm per [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=1381&amp;amp;start=20#p11807]. It will also be necessary to source pulleys with a 1/4&amp;quot; bore (as opposed to the typical 5mm of NEMA 17 motors). A larger plate is needed for the Z-Axis and is available from I.C. on the [http://www.shapeoko.com/upgrades Upgrades page --- NEMA 23 Z-Axis Kit].&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Documented for the ShapeOko 2 in this forum post: [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=2344&amp;amp;p=17845 Re: Caleb's Shapeoko 2 #3164]. [http://www.shapeoko.com/forum/viewtopic.php?f=10&amp;amp;t=2348 NEMA 23 Z-axis for shapeoko 2]. Note that these may need longer fasteners --- 15mm per [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=1381&amp;amp;start=20#p11807]. It will also be necessary to source pulleys with a 1/4&amp;quot; bore (as opposed to the typical 5mm of NEMA 17 motors). A larger plate is needed for the Z-Axis and is available from I.C. on the [http://www.shapeoko.com/upgrades Upgrades page --- NEMA 23 Z-Axis Kit].&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* [http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;#160; Nema23 on Z-Axis] --- includes plans for mount plates. PDF file here: [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=3688&amp;amp;p=27622#p27622 Re: Nema 23 Z Axis Plate] and a link to [http://www.thingiverse.com/thing:269745 Thingiverse].[http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;amp;p=28644]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* [http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;#160; Nema23 on Z-Axis] --- includes plans for mount plates. PDF file here: [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=3688&amp;amp;p=27622#p27622 Re: Nema 23 Z Axis Plate] and a link to [http://www.thingiverse.com/thing:269745 Thingiverse].[http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;amp;p=28644]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 164:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 170:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;=Sources=&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;=Sources=&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;−&lt;/td&gt;&lt;td style=&quot;background: #ffa; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;*[http://www.shapeoko.com/upgrades shapeoko.com] --- Acme Z-Axis, NEMA 23 Z-Axis, DW660 Mounts, [[Dewalt DW660 Dust Shoe|DW660 Dust Shoe]]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;*[http://www.shapeoko.com/upgrades shapeoko.com] --- Acme Z-Axis, NEMA 23 Z-Axis, DW660 Mounts, [[Dewalt DW660 Dust Shoe|DW660 Dust Shoe]]&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;, Z-axis belt drive&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;*[https://www.inventables.com/projects/shapeoko-dual-drive-kit Inventables] --- parts, dual drive kit, open end plate, motor mount plate&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;*[https://www.inventables.com/projects/shapeoko-dual-drive-kit Inventables] --- parts, dual drive kit, open end plate, motor mount plate&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;*[http://www.kbot3dprinting.com/products-page/shapeoko-accessories/ Kbot3D] --- 3D printed upgrade parts including: DW660 Vacuum Attachment/Dust Shoe, Lift Blocks, CNC Table Clamps&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;*[http://www.kbot3dprinting.com/products-page/shapeoko-accessories/ Kbot3D] --- 3D printed upgrade parts including: DW660 Vacuum Attachment/Dust Shoe, Lift Blocks, CNC Table Clamps&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Materials&amp;diff=7522&amp;oldid=7520</id>
		<title>Materials</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Materials&amp;diff=7522&amp;oldid=7520"/>
				<updated>2014-10-27T23:24:37Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;Pine: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 23:24, 27 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 683:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 683:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Forum user Junior483 noted success using the same settings as for MDF.[http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=4490&amp;amp;p=33387#p33387]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Forum user Junior483 noted success using the same settings as for MDF.[http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=4490&amp;amp;p=33387#p33387]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;Stock Shapeoko 2 w/ Altocraft spindle: Plunge depth 0.03125&amp;quot;, feed rate 5 inches per minute --- seemed to tax the spindle. Suggest shallower plunge.[http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=4497&amp;amp;p=33396]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Climb_vs._Conventional_Milling&amp;diff=7521&amp;oldid=6331</id>
		<title>Climb vs. Conventional Milling</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Climb_vs._Conventional_Milling&amp;diff=7521&amp;oldid=6331"/>
				<updated>2014-10-27T21:02:32Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 21:02, 27 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 19:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 19:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Please note that in [http://www.makercam.com/help.html MakerCAM Help] it's advised that “If you're cutting an inside profile, choose counter clockwise. For an outside profile, choose clockwise.”&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Please note that in [http://www.makercam.com/help.html MakerCAM Help] it's advised that “If you're cutting an inside profile, choose counter clockwise. For an outside profile, choose clockwise.”&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;−&lt;/td&gt;&lt;td style=&quot;background: #ffa; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Contrariwise, &amp;quot;Unless your machine is very rigid... you should always do conventional cutting&lt;del class=&quot;diffchange diffchange-inline&quot;&gt;.&lt;/del&gt;&amp;quot;[http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=3414&amp;amp;p=26030#p26030]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Contrariwise, &amp;quot;Unless your machine is very rigid... you should always do conventional cutting&amp;quot;[http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=3414&amp;amp;p=26030#p26030&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;] ... except on low surface energy plastics (HDPE, Polypropylene, etc).[http://www.reddit.com/r/shapeoko/comments/2kcw4k/my_shapeoko_is_up_and_running/cll1e5u&lt;/ins&gt;]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Another recommendation is to climb mill for roughing passes and conventional mill for finishing passes.[http://www.practicalmachinist.com/vb/cnc-machining/climp-vs-conventional-cutting-speed-feed-finish-life-154888/#post861166]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Another recommendation is to climb mill for roughing passes and conventional mill for finishing passes.[http://www.practicalmachinist.com/vb/cnc-machining/climp-vs-conventional-cutting-speed-feed-finish-life-154888/#post861166]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Materials&amp;diff=7520&amp;oldid=7516</id>
		<title>Materials</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Materials&amp;diff=7520&amp;oldid=7516"/>
				<updated>2014-10-27T17:24:27Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;Pine: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 17:24, 27 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 681:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 681:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Forum user atrueresistance reported success in [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=1857&amp;amp;p=14097 So Close, 80 lines left any suggestions]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Forum user atrueresistance reported success in [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=1857&amp;amp;p=14097 So Close, 80 lines left any suggestions]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;Forum user Junior483 noted success using the same settings as for MDF.[http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=4490&amp;amp;p=33387#p33387]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Upgrade_Overview&amp;diff=7519&amp;oldid=7462</id>
		<title>Upgrade Overview</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Upgrade_Overview&amp;diff=7519&amp;oldid=7462"/>
				<updated>2014-10-27T16:01:59Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 16:01, 27 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 136:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 136:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;[[File:ROTARY_dEVICE.jpg |rotary axis]]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;[[File:ROTARY_dEVICE.jpg |rotary axis]]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;−&lt;/td&gt;&lt;td style=&quot;background: #ffa; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;==NEMA 23 motors==&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;==Motors==&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&amp;#160;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;=&lt;/ins&gt;==NEMA 23 motors&lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;=&lt;/ins&gt;==&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Documented for the ShapeOko 2 in this forum post: [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=2344&amp;amp;p=17845 Re: Caleb's Shapeoko 2 #3164]. [http://www.shapeoko.com/forum/viewtopic.php?f=10&amp;amp;t=2348 NEMA 23 Z-axis for shapeoko 2]. Note that these may need longer fasteners --- 15mm per [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=1381&amp;amp;start=20#p11807]. It will also be necessary to source pulleys with a 1/4&amp;quot; bore (as opposed to the typical 5mm of NEMA 17 motors). A larger plate is needed for the Z-Axis and is available from I.C. on the [http://www.shapeoko.com/upgrades Upgrades page --- NEMA 23 Z-Axis Kit].&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Documented for the ShapeOko 2 in this forum post: [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=2344&amp;amp;p=17845 Re: Caleb's Shapeoko 2 #3164]. [http://www.shapeoko.com/forum/viewtopic.php?f=10&amp;amp;t=2348 NEMA 23 Z-axis for shapeoko 2]. Note that these may need longer fasteners --- 15mm per [http://www.shapeoko.com/forum/viewtopic.php?f=5&amp;amp;t=1381&amp;amp;start=20#p11807]. It will also be necessary to source pulleys with a 1/4&amp;quot; bore (as opposed to the typical 5mm of NEMA 17 motors). A larger plate is needed for the Z-Axis and is available from I.C. on the [http://www.shapeoko.com/upgrades Upgrades page --- NEMA 23 Z-Axis Kit].&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* [http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;#160; Nema23 on Z-Axis] --- includes plans for mount plates. PDF file here: [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=3688&amp;amp;p=27622#p27622 Re: Nema 23 Z Axis Plate] and a link to [http://www.thingiverse.com/thing:269745 Thingiverse].[http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;amp;p=28644]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* [http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;#160; Nema23 on Z-Axis] --- includes plans for mount plates. PDF file here: [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=3688&amp;amp;p=27622#p27622 Re: Nema 23 Z Axis Plate] and a link to [http://www.thingiverse.com/thing:269745 Thingiverse].[http://www.shapeoko.com/forum/viewtopic.php?f=11&amp;amp;t=2754&amp;amp;p=28644]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 144:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 146:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Notes on motor selection size: You don't want a motor heavier than about 700 g, mostly because there's absolutely no point to it. Why would you want to be able to apply, say, 600 N to the gantry or X carriage, when you know that 100 N on your tool will flex the machine too much to be usable?[http://www.shapeoko.com/forum/viewtopic.php?f=4&amp;amp;t=4328&amp;amp;p=32317]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Notes on motor selection size: You don't want a motor heavier than about 700 g, mostly because there's absolutely no point to it. Why would you want to be able to apply, say, 600 N to the gantry or X carriage, when you know that 100 N on your tool will flex the machine too much to be usable?[http://www.shapeoko.com/forum/viewtopic.php?f=4&amp;amp;t=4328&amp;amp;p=32317]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;===Z-axis Drive options===&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;For the Z-axis, rather than directly driving the threaded/Acme rod, it's possible to use a belt drive:&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;* [http://shop.shapeoko.com/collections/frontpage/products/shapeoko-2-nema17-belt-drive-z-axis-kit NEMA17 Belt Drive Z-Axis Kit]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;* [http://shop.shapeoko.com/collections/frontpage/products/shapeoko-2-belt-drive-nema-23-z-axis-kit Belt Drive NEMA 23 Z-Axis Kit]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;Discussion here: http://www.shapeoko.com/forum/viewtopic.php?f=12&amp;amp;t=4368 and source files are available in this post: http://www.shapeoko.com/forum/viewtopic.php?f=12&amp;amp;t=4368&amp;amp;p=33383&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;==Controller Modifications==&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;==Controller Modifications==&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=3D_Printing&amp;diff=7518&amp;oldid=7501</id>
		<title>3D Printing</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=3D_Printing&amp;diff=7518&amp;oldid=7501"/>
				<updated>2014-10-26T18:52:22Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;Software: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 18:52, 26 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan='4' align='center' class='diff-multi'&gt;(One intermediate revision by one user not shown)&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 60:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 60:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;In addition to the standard [[CAD#3D|3D CAD software]] ([http://reprap.org/wiki/Art_of_illusion Art of Illusion is a frequent suggestion]), 3D printing requires additional specialized software. See also http://reprap.org/wiki/CAM_Toolchains&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;In addition to the standard [[CAD#3D|3D CAD software]] ([http://reprap.org/wiki/Art_of_illusion Art of Illusion is a frequent suggestion]), 3D printing requires additional specialized software. See also http://reprap.org/wiki/CAM_Toolchains&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;−&lt;/td&gt;&lt;td style=&quot;background: #ffa; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;One option is to draw geometry in a 2D program such as [[Inkscape]], export to .dxf, then import that into [[OpenSCAD]] as shown in http://www.appropedia.org/Converting_2D_images_to_3D_for_printing_using_open_source_software&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;One option is to draw geometry in a 2D program such as [[Inkscape]], export to .dxf, then import that into [[OpenSCAD]] as shown in http://www.appropedia.org/Converting_2D_images_to_3D_for_printing_using_open_source_software &lt;ins class=&quot;diffchange diffchange-inline&quot;&gt;or to directly export to OpenSCAD using a plug-in such as http://libregraphicsworld.org/blog/entry/inkscape-gets-openscad-converter&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;===Previewers===&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;===Previewers===&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Materials&amp;diff=7516&amp;oldid=7496</id>
		<title>Materials</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Materials&amp;diff=7516&amp;oldid=7496"/>
				<updated>2014-10-26T01:27:59Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;PCB: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 01:27, 26 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 802:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 802:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Copper circuit board cut on the forums [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=420 here]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Copper circuit board cut on the forums [http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=420 here]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;Inventables blog post; http://blog.inventables.com/2014/02/circuit-board-milling-on-shapeoko-2.html&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Especially clean [http://www.shapeoko.com/forum/viewtopic.php?f=28&amp;amp;t=3885&amp;amp;p=29188#p29170 Double Sided PCB] cut &amp;quot;using a 0.3mm end mill with lots of WD40 on the board.... (F)eedrate is 4ipm and depth is 0.005 inches.&amp;quot;&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;Especially clean [http://www.shapeoko.com/forum/viewtopic.php?f=28&amp;amp;t=3885&amp;amp;p=29188#p29170 Double Sided PCB] cut &amp;quot;using a 0.3mm end mill with lots of WD40 on the board.... (F)eedrate is 4ipm and depth is 0.005 inches.&amp;quot;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Laser_Cutter&amp;diff=7515&amp;oldid=7382</id>
		<title>Laser Cutter</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Laser_Cutter&amp;diff=7515&amp;oldid=7382"/>
				<updated>2014-10-25T11:24:26Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;Alternative Designs: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 11:24, 25 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 64:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 64:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://www.3ders.org/articles/20131104-turn-your-3d-printer-into-an-instant-laser-cutter.html&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://www.3ders.org/articles/20131104-turn-your-3d-printer-into-an-instant-laser-cutter.html&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://www.instructables.com/id/CNC-Laser-for-Printing-Images-and-Engraving-Shapeo/ --- 2 Watts&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://www.instructables.com/id/CNC-Laser-for-Printing-Images-and-Engraving-Shapeo/ --- 2 Watts&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;* http://www.instructables.com/id/Shapeoko-2-Arduino-UNO-R3-grbl-9g-8bit-Raster-Phot/ [http://www.shapeoko.com/forum/viewtopic.php?f=24&amp;amp;t=4480&amp;amp;p=33321]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://makerfaire.com/makers/laser-ink-2/&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;* http://makerfaire.com/makers/laser-ink-2/&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	<entry>
		<id>http://www.shapeoko.com/wiki/index.php?title=Operation_Troubleshooting&amp;diff=7514&amp;oldid=7486</id>
		<title>Operation Troubleshooting</title>
		<link rel="alternate" type="text/html" href="http://www.shapeoko.com/wiki/index.php?title=Operation_Troubleshooting&amp;diff=7514&amp;oldid=7486"/>
				<updated>2014-10-24T15:35:39Z</updated>
		
		<summary type="html">&lt;p&gt;&lt;span class=&quot;autocomment&quot;&gt;One Axis Quits Working or Works Intermittently: &lt;/span&gt; &lt;/p&gt;
&lt;table class='diff diff-contentalign-left'&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
			&lt;col class='diff-marker' /&gt;
			&lt;col class='diff-content' /&gt;
		&lt;tr valign='top'&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;← Older revision&lt;/td&gt;
		&lt;td colspan='2' style=&quot;background-color: white; color:black;&quot;&gt;Revision as of 15:35, 24 October 2014&lt;/td&gt;
		&lt;/tr&gt;&lt;tr&gt;&lt;td colspan='4' align='center' class='diff-multi'&gt;(One intermediate revision by one user not shown)&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 87:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 87:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;:''End mill loose in collet --- this can also cause other path deviations as the needed cutting forces are increased beyond the machine's capabilities.''&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;:''End mill loose in collet --- this can also cause other path deviations as the needed cutting forces are increased beyond the machine's capabilities.''&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;::Tighten collet.[http://www.shapeoko.com/forum/viewtopic.php?f=6&amp;amp;t=4385&amp;amp;p=32593]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;::Tighten collet.[http://www.shapeoko.com/forum/viewtopic.php?f=6&amp;amp;t=4385&amp;amp;p=32593]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;'''Z-axis cuts at odd angles when cutting thin stock''': The bit is pulling the material up or twisting it as it cuts.&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;::Switch to a down-cutting spiral bit --- check and ensure the bit is sharp.[http://www.shapeoko.com/forum/viewtopic.php?f=7&amp;amp;t=4466&amp;amp;p=33240#p33240]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;'''Lines are not straight, circles not round, dog bone pattern at corners, cut quality poor'''&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;'''Lines are not straight, circles not round, dog bone pattern at corners, cut quality poor'''&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 165:&lt;/td&gt;
&lt;td colspan=&quot;2&quot; class=&quot;diff-lineno&quot;&gt;Line 168:&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;If the machine is operated w/ a loose wire, then the stepper driver chip may be damaged. In that event, it can be replaced, merely by unplugging and replacing on a board w/ socketed stepper drivers, by desoldering/resoldering a new chip on other boards.[http://www.shapeoko.com/forum/viewtopic.php?f=3&amp;amp;t=1550#p12366]&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;If the machine is operated w/ a loose wire, then the stepper driver chip may be damaged. In that event, it can be replaced, merely by unplugging and replacing on a board w/ socketed stepper drivers, by desoldering/resoldering a new chip on other boards.[http://www.shapeoko.com/forum/viewtopic.php?f=3&amp;amp;t=1550#p12366]&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;===Motor oddly snaps after finishing a movement===&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&amp;#160;&lt;/td&gt;&lt;td class='diff-marker'&gt;+&lt;/td&gt;&lt;td style=&quot;background: #cfc; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;&lt;ins style=&quot;color: red; font-weight: bold; text-decoration: none;&quot;&gt;This is caused by disabling motor holding.[http://www.shapeoko.com/forum/viewtopic.php?f=4&amp;amp;t=4478&amp;amp;p=33292]&lt;/ins&gt;&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;==Electronics Troubleshooting Checklist==&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;==Electronics Troubleshooting Checklist==&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;http://www.shapeoko.com/forum/viewtopic.php?f=4&amp;amp;t=3888&amp;amp;p=29205&lt;/div&gt;&lt;/td&gt;&lt;td class='diff-marker'&gt;&amp;#160;&lt;/td&gt;&lt;td style=&quot;background: #eee; color:black; font-size: smaller;&quot;&gt;&lt;div&gt;http://www.shapeoko.com/forum/viewtopic.php?f=4&amp;amp;t=3888&amp;amp;p=29205&lt;/div&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</summary>
		<author><name>Willadams</name></author>	</entry>

	</feed>