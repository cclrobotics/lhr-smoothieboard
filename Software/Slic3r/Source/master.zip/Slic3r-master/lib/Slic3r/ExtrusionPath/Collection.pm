package Slic3r::ExtrusionPath::Collection;
use strict;
use warnings;

1;
