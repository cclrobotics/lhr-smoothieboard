package Slic3r::Fill::HilbertCurve;
use Moo;

extends 'Slic3r::Fill::PlanePath';
use Math::PlanePath::HilbertCurve;

1;
