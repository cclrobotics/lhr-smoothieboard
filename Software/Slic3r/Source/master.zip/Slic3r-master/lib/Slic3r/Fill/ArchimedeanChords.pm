package Slic3r::Fill::ArchimedeanChords;
use Moo;

extends 'Slic3r::Fill::PlanePath';
use Math::PlanePath::ArchimedeanChords;

1;
