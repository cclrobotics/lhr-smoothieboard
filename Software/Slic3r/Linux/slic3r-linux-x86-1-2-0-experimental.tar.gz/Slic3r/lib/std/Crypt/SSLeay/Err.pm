package Crypt::SSLeay::Err;
require Crypt::SSLeay;
use strict;
1;
